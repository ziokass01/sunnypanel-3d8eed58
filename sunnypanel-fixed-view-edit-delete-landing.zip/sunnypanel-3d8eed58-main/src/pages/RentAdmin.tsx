import { useEffect, useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/auth/AuthProvider";
import { postFunction } from "@/lib/functions";
import { useToast } from "@/hooks/use-toast";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type RentAccount = {
  id: string;
  username: string;
  created_at: string;
  expires_at: string | null;
  max_devices: number;
  is_disabled: boolean;
  hmac_secret: string;
  note: string | null;
};

type ActivationKeyRow = {
  id: string;
  code: string;
  duration_seconds: number;
  created_at: string;
  claimed_by: string | null;
  claimed_at: string | null;
  revoked_at: string | null;
  note: string | null;
};

type ResetCodeRow = {
  id: string;
  created_at: string;
  expires_at: string;
  used_at: string | null;
};

type ApiOk<T> = { ok: true } & T;

function fmtDate(s: string | null | undefined) {
  if (!s) return "-";
  try {
    return new Date(s).toLocaleString();
  } catch {
    return String(s);
  }
}

async function copyText(t: string) {
  try {
    await navigator.clipboard.writeText(t);
    return true;
  } catch {
    return false;
  }
}

export function RentAdminPage() {
  const { session } = useAuth();
  const authToken = session?.access_token ?? null;
  const { toast } = useToast();
  const qc = useQueryClient();

  // Create user
  const [newUsername, setNewUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newHmac, setNewHmac] = useState("");
  const [newMaxDevices, setNewMaxDevices] = useState("1");
  const [newNote, setNewNote] = useState("");

  // Global settings
  const [issueDays, setIssueDays] = useState("30");
  const [issueNote, setIssueNote] = useState("");
  const [customActivationKey, setCustomActivationKey] = useState("");

  const [resetMinutes, setResetMinutes] = useState("30");

  // Dialog state
  const [selected, setSelected] = useState<RentAccount | null>(null);
  const [openView, setOpenView] = useState(false);
  const [openEdit, setOpenEdit] = useState(false);

  // Edit fields (per-user)
  const [editMaxDevices, setEditMaxDevices] = useState("1");
  const [editDisabled, setEditDisabled] = useState(false);
  const [editNote, setEditNote] = useState("");

  const [customRotateHmac, setCustomRotateHmac] = useState("");

  const usersQ = useQuery({
    queryKey: ["rent-admin", "users"],
    enabled: !!authToken,
    queryFn: async () => {
      const res = await postFunction<ApiOk<{ users: RentAccount[] }>>(
        "/admin-rent",
        { action: "list_users" },
        { authToken },
      );
      return res.users;
    },
  });

  const activationKeysQ = useQuery({
    queryKey: ["rent-admin", "activation-keys"],
    enabled: !!authToken,
    queryFn: async () => {
      const res = await postFunction<ApiOk<{ keys: ActivationKeyRow[] }>>(
        "/admin-rent",
        { action: "list_activation_keys", limit: 30 },
        { authToken },
      );
      return res.keys;
    },
  });

  const resetHistoryQ = useQuery({
    queryKey: ["rent-admin", "reset-codes", selected?.id],
    enabled: !!authToken && !!selected?.id && (openView || openEdit),
    queryFn: async () => {
      const res = await postFunction<ApiOk<{ rows: ResetCodeRow[] }>>(
        "/admin-rent",
        { action: "list_reset_codes", account_id: selected!.id, limit: 20 },
        { authToken },
      );
      return res.rows;
    },
  });

  const createUserM = useMutation({
    mutationFn: async () => {
      const max_devices = Math.max(1, Math.min(20, parseInt(newMaxDevices || "1", 10) || 1));
      const res = await postFunction<ApiOk<{ user: RentAccount; generated_hmac?: string }>>(
        "/admin-rent",
        {
          action: "create_user",
          username: newUsername.trim(),
          password: newPassword,
          hmac_secret: newHmac.trim() || null,
          max_devices,
          note: newNote.trim() || null,
        },
        { authToken },
      );
      return res;
    },
    onSuccess: async (res) => {
      if (res.generated_hmac) {
        await copyText(res.generated_hmac);
      }
      toast({
        title: "Tạo tài khoản thuê thành công",
        description: res.generated_hmac
          ? `HMAC đã random (đã copy): ${res.generated_hmac}`
          : "Đã tạo user.",
      });
      setNewUsername("");
      setNewPassword("");
      setNewHmac("");
      setNewNote("");
      qc.invalidateQueries({ queryKey: ["rent-admin", "users"] });
    },
    onError: (e: any) => {
      toast({ title: "Lỗi tạo user", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const updateUserM = useMutation({
    mutationFn: async () => {
      if (!selected) throw new Error("NO_SELECTED");
      const max_devices = Math.max(1, Math.min(20, parseInt(editMaxDevices || "1", 10) || 1));
      const res = await postFunction<ApiOk<{ user: RentAccount }>>(
        "/admin-rent",
        {
          action: "update_user",
          account_id: selected.id,
          max_devices,
          is_disabled: editDisabled,
          note: editNote.trim() || null,
        },
        { authToken },
      );
      return res.user;
    },
    onSuccess: (u) => {
      toast({ title: "Đã cập nhật user" });
      setSelected(u);
      qc.invalidateQueries({ queryKey: ["rent-admin", "users"] });
    },
    onError: (e: any) => {
      toast({ title: "Lỗi cập nhật", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const issueKeyM = useMutation({
    mutationFn: async () => {
      if (!selected) throw new Error("NO_SELECTED");
      const days = Math.max(1, Math.min(3650, parseInt(issueDays || "30", 10) || 30));
      const res = await postFunction<ApiOk<{ code: string; duration_seconds: number }>>(
        "/admin-rent",
        {
          action: "issue_activation",
          account_id: selected.id,
          days,
          note: issueNote.trim() || null,
          custom_code: customActivationKey.trim() ? customActivationKey.trim().toUpperCase() : null,
        },
        { authToken },
      );
      return res;
    },
    onSuccess: async (res) => {
      await copyText(res.code);
      toast({
        title: "Đã tạo key kích hoạt (đã copy)",
        description: `Key: ${res.code} (+${Math.round(res.duration_seconds / 86400)} ngày)`,
      });
      setCustomActivationKey("");
      qc.invalidateQueries({ queryKey: ["rent-admin", "activation-keys"] });
    },
    onError: (e: any) => {
      toast({ title: "Lỗi tạo key kích hoạt", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const resetCodeM = useMutation({
    mutationFn: async () => {
      if (!selected) throw new Error("NO_SELECTED");
      const minutes = Math.max(5, Math.min(24 * 60, parseInt(resetMinutes || "30", 10) || 30));
      const res = await postFunction<ApiOk<{ code: string; expires_at: string }>>(
        "/admin-rent",
        { action: "create_reset_code", account_id: selected.id, minutes },
        { authToken },
      );
      return res;
    },
    onSuccess: async (res) => {
      await copyText(res.code);
      toast({
        title: "Đã tạo code đổi mật khẩu (đã copy)",
        description: `Code: ${res.code} (hết hạn: ${fmtDate(res.expires_at)})`,
      });
      qc.invalidateQueries({ queryKey: ["rent-admin", "reset-codes", selected?.id] });
    },
    onError: (e: any) => {
      toast({ title: "Lỗi tạo reset code", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const resetDefaultM = useMutation({
    mutationFn: async () => {
      if (!selected) throw new Error("NO_SELECTED");
      const res = await postFunction<ApiOk<{ default_password: string }>>(
        "/admin-rent",
        { action: "reset_password_default", account_id: selected.id },
        { authToken },
      );
      return res;
    },
    onSuccess: async (res) => {
      await copyText(res.default_password);
      toast({
        title: "Đã reset mật khẩu về mặc định (đã copy)",
        description: `Mật khẩu mặc định: ${res.default_password}`,
      });
    },
    onError: (e: any) => {
      toast({ title: "Lỗi reset mật khẩu", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const rotateHmacM = useMutation({
    mutationFn: async () => {
      if (!selected) throw new Error("NO_SELECTED");
      const res = await postFunction<ApiOk<{ new_hmac_secret: string; new_expires_at: string | null; penalized: boolean }>>(
        "/admin-rent",
        {
          action: "rotate_hmac",
          account_id: selected.id,
          new_hmac: customRotateHmac.trim() ? customRotateHmac.trim() : null,
        },
        { authToken },
      );
      return res;
    },
    onSuccess: async (res) => {
      await copyText(res.new_hmac_secret);
      toast({
        title: "Đã rotate HMAC (đã copy)",
        description: `HMAC mới: ${res.new_hmac_secret}${res.penalized ? " (đã trừ 20% thời gian còn lại)" : ""}`,
      });
      setCustomRotateHmac("");
      qc.invalidateQueries({ queryKey: ["rent-admin", "users"] });
      // Refresh selected user (view/edit)
      const latest = (usersQ.data ?? []).find((u) => u.id === selected?.id);
      if (latest) setSelected(latest);
    },
    onError: (e: any) => {
      toast({ title: "Lỗi rotate HMAC", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const deleteUserM = useMutation({
    mutationFn: async () => {
      if (!selected) throw new Error("NO_SELECTED");
      const res = await postFunction<ApiOk<{}>>(
        "/admin-rent",
        { action: "delete_user", account_id: selected.id },
        { authToken },
      );
      return res;
    },
    onSuccess: () => {
      toast({ title: "Đã xóa user thuê" });
      setOpenView(false);
      setOpenEdit(false);
      setSelected(null);
      qc.invalidateQueries({ queryKey: ["rent-admin", "users"] });
    },
    onError: (e: any) => {
      toast({ title: "Lỗi xóa user", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const users = usersQ.data ?? [];

  const selectedId = selected?.id ?? null;
  const selectedFresh = useMemo(() => {
    if (!selectedId) return null;
    return users.find((u) => u.id === selectedId) ?? selected;
  }, [users, selectedId, selected]);

  useEffect(() => {
    if (!selectedFresh) return;
    setEditMaxDevices(String(selectedFresh.max_devices ?? 1));
    setEditDisabled(!!selectedFresh.is_disabled);
    setEditNote(selectedFresh.note ?? "");
  }, [selectedFresh?.id]);

  const openViewFor = (u: RentAccount) => {
    setSelected(u);
    setOpenView(true);
  };

  const openEditFor = (u: RentAccount) => {
    setSelected(u);
    setOpenEdit(true);
  };

  const activationKeys = activationKeysQ.data ?? [];

  return (
    <div className="mx-auto w-full max-w-6xl space-y-6 p-4">
      <div>
        <h1 className="text-xl font-semibold">Thuê Website</h1>
        <p className="text-sm text-muted-foreground">
          Tab này quản lý tài khoản thuê. Key kích hoạt ở đây là riêng, KHÔNG liên quan Licenses/Free.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Tạo tài khoản thuê</CardTitle>
          <CardDescription>
            Admin tạo username/password + HMAC secret riêng (chống dùng chung). HMAC có thể random hoặc tự nhập.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label>Username</Label>
            <Input value={newUsername} onChange={(e) => setNewUsername(e.target.value)} placeholder="vd: user123" />
            <p className="text-xs text-muted-foreground">Không trùng. Không dùng email để tránh lẫn auth admin.</p>
          </div>
          <div className="space-y-2">
            <Label>Password</Label>
            <Input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="••••••••" />
            <p className="text-xs text-muted-foreground">Mật khẩu user thuê (khác admin).</p>
          </div>
          <div className="space-y-2">
            <Label>HMAC secret (tuỳ chọn)</Label>
            <Input value={newHmac} onChange={(e) => setNewHmac(e.target.value)} placeholder="để trống = random" />
            <p className="text-xs text-muted-foreground">Để trống thì server tự random & unique.</p>
          </div>
          <div className="space-y-2">
            <Label>Max devices</Label>
            <Input value={newMaxDevices} onChange={(e) => setNewMaxDevices(e.target.value)} placeholder="1" />
            <p className="text-xs text-muted-foreground">Giới hạn số thiết bị / key verify.</p>
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label>Note (tuỳ chọn)</Label>
            <Textarea value={newNote} onChange={(e) => setNewNote(e.target.value)} placeholder="Ghi chú..." />
          </div>

          <div className="md:col-span-2">
            <Button
              onClick={() => createUserM.mutate()}
              disabled={!authToken || createUserM.isPending || !newUsername.trim() || !newPassword}
            >
              {createUserM.isPending ? "Đang tạo..." : "Tạo user thuê"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Danh sách user thuê</CardTitle>
          <CardDescription>
            Chỉ còn 3 thao tác trên bảng: View / Edit / Xóa. Các thao tác nhạy cảm được đưa vào Edit.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Username</TableHead>
                  <TableHead>Hết hạn</TableHead>
                  <TableHead>Max devices</TableHead>
                  <TableHead>Disabled</TableHead>
                  <TableHead>HMAC</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell className="font-medium">{u.username}</TableCell>
                    <TableCell>{u.expires_at ? fmtDate(u.expires_at) : "Chưa kích hoạt"}</TableCell>
                    <TableCell>{u.max_devices}</TableCell>
                    <TableCell>
                      <Switch checked={u.is_disabled} disabled />
                    </TableCell>
                    <TableCell className="max-w-[240px] truncate" title={u.hmac_secret}>{u.hmac_secret}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button size="sm" variant="soft" onClick={() => openViewFor(u)}>View</Button>
                      <Button size="sm" variant="soft" onClick={() => openEditFor(u)}>Edit</Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => {
                          setSelected(u);
                          deleteUserM.mutate();
                        }}
                        disabled={deleteUserM.isPending}
                      >
                        Xóa
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {users.length === 0 && !usersQ.isLoading && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-sm text-muted-foreground">
                      Chưa có user thuê.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* VIEW */}
      <Dialog open={openView} onOpenChange={setOpenView}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>View user thuê</DialogTitle>
            <DialogDescription>
              Chỉ xem thông tin + thời hạn + lịch sử key kích hoạt (để không bị "tạo xong mất luôn").
            </DialogDescription>
          </DialogHeader>

          {selectedFresh ? (
            <div className="space-y-4">
              <div className="grid gap-3 md:grid-cols-2">
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">Username</div>
                  <div className="font-medium">{selectedFresh.username}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">Created</div>
                  <div className="font-medium">{fmtDate(selectedFresh.created_at)}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">Expires</div>
                  <div className="font-medium">{selectedFresh.expires_at ? fmtDate(selectedFresh.expires_at) : "Chưa kích hoạt"}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">Max devices</div>
                  <div className="font-medium">{selectedFresh.max_devices}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">Disabled</div>
                  <div className="font-medium">{selectedFresh.is_disabled ? "YES" : "NO"}</div>
                </div>
                <div className="space-y-1">
                  <div className="text-xs text-muted-foreground">HMAC</div>
                  <div className="flex items-center gap-2">
                    <div className="font-mono text-xs truncate" title={selectedFresh.hmac_secret}>{selectedFresh.hmac_secret}</div>
                    <Button
                      size="sm"
                      variant="soft"
                      onClick={async () => {
                        const ok = await copyText(selectedFresh.hmac_secret);
                        toast({ title: ok ? "Đã copy" : "Không copy được" });
                      }}
                    >
                      Copy
                    </Button>
                  </div>
                </div>
              </div>

              {selectedFresh.note && (
                <div className="rounded-lg border p-3 text-sm">
                  <div className="text-xs text-muted-foreground">Note</div>
                  <div className="whitespace-pre-wrap">{selectedFresh.note}</div>
                </div>
              )}

              <Separator />

              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-medium">Lịch sử activation keys (gần nhất)</div>
                  <Button size="sm" variant="soft" onClick={() => activationKeysQ.refetch()} disabled={activationKeysQ.isFetching}>Refresh</Button>
                </div>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Key</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead>Days</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {activationKeys.slice(0, 15).map((k) => {
                        const days = Math.round((k.duration_seconds ?? 0) / 86400);
                        const status = k.revoked_at
                          ? "Revoked"
                          : k.claimed_at
                            ? "Claimed"
                            : "Unused";
                        return (
                          <TableRow key={k.id}>
                            <TableCell className="font-mono text-xs">
                              <div className="flex items-center gap-2">
                                <span>{k.code}</span>
                                <Button
                                  size="sm"
                                  variant="soft"
                                  onClick={async () => {
                                    const ok = await copyText(k.code);
                                    toast({ title: ok ? "Đã copy" : "Không copy được" });
                                  }}
                                >
                                  Copy
                                </Button>
                              </div>
                              {k.note && <div className="text-[11px] text-muted-foreground truncate" title={k.note}>{k.note}</div>}
                            </TableCell>
                            <TableCell>{fmtDate(k.created_at)}</TableCell>
                            <TableCell>{days}</TableCell>
                            <TableCell>
                              {status}
                              {k.claimed_at ? <div className="text-[11px] text-muted-foreground">{fmtDate(k.claimed_at)}</div> : null}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                      {activationKeys.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-sm text-muted-foreground">Chưa có activation key.</TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
                <div className="text-xs text-muted-foreground">Tip: tạo key mới nằm trong Edit để tránh lộ trên bảng.</div>
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="font-medium">Reset code history (không hiển thị code vì DB chỉ lưu hash)</div>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Created</TableHead>
                        <TableHead>Expires</TableHead>
                        <TableHead>Used</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(resetHistoryQ.data ?? []).map((r) => (
                        <TableRow key={r.id}>
                          <TableCell>{fmtDate(r.created_at)}</TableCell>
                          <TableCell>{fmtDate(r.expires_at)}</TableCell>
                          <TableCell>{r.used_at ? fmtDate(r.used_at) : "-"}</TableCell>
                        </TableRow>
                      ))}
                      {(resetHistoryQ.data ?? []).length === 0 && (
                        <TableRow>
                          <TableCell colSpan={3} className="text-center text-sm text-muted-foreground">Chưa có reset code.</TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="soft" onClick={() => { setOpenView(false); setSelected(null); }}>Đóng</Button>
                <Button onClick={() => { setOpenView(false); setOpenEdit(true); }}>Sang Edit</Button>
              </div>
            </div>
          ) : (
            <div className="text-sm text-muted-foreground">Chưa chọn user.</div>
          )}
        </DialogContent>
      </Dialog>

      {/* EDIT */}
      <Dialog open={openEdit} onOpenChange={setOpenEdit}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Edit user thuê</DialogTitle>
            <DialogDescription>
              Chỉnh max devices / disable / note và thao tác: tạo activation key, reset code, rotate HMAC, reset pass.
            </DialogDescription>
          </DialogHeader>

          {selectedFresh ? (
            <div className="space-y-5">
              <div className="rounded-lg border p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <div className="text-xs text-muted-foreground">User</div>
                    <div className="font-medium">{selectedFresh.username}</div>
                  </div>
                  <div className="text-sm">
                    <span className="text-xs text-muted-foreground">Expires: </span>
                    <span className="font-medium">{selectedFresh.expires_at ? fmtDate(selectedFresh.expires_at) : "Chưa kích hoạt"}</span>
                  </div>
                </div>
              </div>

              <div className="grid gap-3 md:grid-cols-3">
                <div className="space-y-2">
                  <Label>Max devices</Label>
                  <Input value={editMaxDevices} onChange={(e) => setEditMaxDevices(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>Disabled</Label>
                  <div className="flex items-center gap-2 pt-2">
                    <Switch checked={editDisabled} onCheckedChange={setEditDisabled} />
                    <div className="text-sm text-muted-foreground">Tắt/bật tài khoản thuê</div>
                  </div>
                </div>
                <div className="space-y-2 md:col-span-3">
                  <Label>Note</Label>
                  <Textarea value={editNote} onChange={(e) => setEditNote(e.target.value)} placeholder="Ghi chú..." />
                </div>
                <div className="md:col-span-3">
                  <Button onClick={() => updateUserM.mutate()} disabled={updateUserM.isPending}>
                    {updateUserM.isPending ? "Đang lưu..." : "Lưu thay đổi"}
                  </Button>
                </div>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="font-medium">Tạo activation key (dùng 1 lần)</div>
                <div className="grid gap-3 md:grid-cols-3">
                  <div className="space-y-2">
                    <Label>Days</Label>
                    <Input value={issueDays} onChange={(e) => setIssueDays(e.target.value)} />
                    <p className="text-xs text-muted-foreground">Thời hạn cộng thêm khi user kích hoạt.</p>
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label>Note (tuỳ chọn)</Label>
                    <Input value={issueNote} onChange={(e) => setIssueNote(e.target.value)} placeholder="vd: gói 1 tháng" />
                  </div>
                  <div className="space-y-2 md:col-span-3">
                    <Label>Key 1 (tự nhập) — để trống = Key 2 (random)</Label>
                    <Input value={customActivationKey} onChange={(e) => setCustomActivationKey(e.target.value)} placeholder="ABCD-EFGH-IJKL-MNOP" />
                    <p className="text-xs text-muted-foreground">Format: 4 nhóm x 4 ký tự (A-Z/0-9). Để trống thì server random.</p>
                  </div>
                </div>
                <Button onClick={() => issueKeyM.mutate()} disabled={issueKeyM.isPending}>
                  {issueKeyM.isPending ? "Đang tạo..." : "Tạo activation key"}
                </Button>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="font-medium">Reset code (1 lần)</div>
                <div className="grid gap-3 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Hết hạn (phút)</Label>
                    <Input value={resetMinutes} onChange={(e) => setResetMinutes(e.target.value)} />
                    <p className="text-xs text-muted-foreground">Code trả về 1 lần (toast + copy). DB chỉ lưu hash.</p>
                  </div>
                </div>
                <Button variant="soft" onClick={() => resetCodeM.mutate()} disabled={resetCodeM.isPending}>
                  {resetCodeM.isPending ? "Đang tạo..." : "Tạo reset code"}
                </Button>
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="font-medium">Rotate HMAC</div>
                <div className="space-y-2">
                  <Label>HMAC 1 (tự nhập) — để trống = random</Label>
                  <Input value={customRotateHmac} onChange={(e) => setCustomRotateHmac(e.target.value)} placeholder="để trống = random" />
                  <p className="text-xs text-muted-foreground">Nếu user đang còn hạn, rotate sẽ trừ 20% thời gian còn lại.</p>
                </div>
                <Button variant="soft" onClick={() => rotateHmacM.mutate()} disabled={rotateHmacM.isPending}>
                  {rotateHmacM.isPending ? "Đang rotate..." : "Rotate HMAC"}
                </Button>
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="font-medium">Reset mật khẩu về mặc định</div>
                <Button variant="soft" onClick={() => resetDefaultM.mutate()} disabled={resetDefaultM.isPending}>
                  {resetDefaultM.isPending ? "Đang reset..." : "Reset pass"}
                </Button>
              </div>

              <Separator />

              <div className="flex flex-wrap justify-end gap-2">
                <Button variant="soft" onClick={() => { setOpenEdit(false); setSelected(null); }}>Đóng</Button>
                <Button
                  variant="destructive"
                  onClick={() => deleteUserM.mutate()}
                  disabled={deleteUserM.isPending}
                >
                  {deleteUserM.isPending ? "Đang xóa..." : "Xóa user"}
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-sm text-muted-foreground">Chưa chọn user.</div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
