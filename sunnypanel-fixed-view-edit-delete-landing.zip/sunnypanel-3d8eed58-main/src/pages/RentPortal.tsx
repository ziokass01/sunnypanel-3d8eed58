import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { postFunction } from "@/lib/functions";
import { useToast } from "@/hooks/use-toast";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

type ApiOk<T> = { ok: true } & T;

type MeResponse = {
  account: {
    id: string;
    username: string;
    expires_at: string | null;
    max_devices: number;
    is_disabled: boolean;
  };
};

type RentKey = {
  id: string;
  key: string;
  created_at: string;
  is_active: boolean;
  note: string | null;
};

const LS_TOKEN = "rent_token_v1";

function normalizeKeyInput(s: string) {
  return s.trim().toUpperCase();
}

export function RentPortalPage() {
  const { toast } = useToast();
  const qc = useQueryClient();

  const [token, setToken] = useState<string | null>(() => {
    if (typeof window === "undefined") return null;
    return window.localStorage.getItem(LS_TOKEN);
  });

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [activationKey, setActivationKey] = useState("");

  const [customKey, setCustomKey] = useState("");
  const [keyNote, setKeyNote] = useState("");

  const [resetCode, setResetCode] = useState("");
  const [newPass, setNewPass] = useState("");

  const logout = () => {
    if (typeof window !== "undefined") window.localStorage.removeItem(LS_TOKEN);
    setToken(null);
    qc.clear();
  };

  const meQ = useQuery({
    queryKey: ["rent", "me", token],
    enabled: !!token,
    queryFn: async () => {
      const res = await postFunction<ApiOk<MeResponse>>(
        "/rent-user",
        { action: "me" },
        { authToken: token ?? undefined },
      );
      return res.account;
    },
    retry: false,
  });

  const keysQ = useQuery({
    queryKey: ["rent", "keys", token],
    enabled: !!token && !!meQ.data && !!meQ.data.expires_at && new Date(meQ.data.expires_at).getTime() > Date.now() && !meQ.data.is_disabled,
    queryFn: async () => {
      const res = await postFunction<ApiOk<{ keys: RentKey[] }>>(
        "/rent-user",
        { action: "list_keys" },
        { authToken: token ?? undefined },
      );
      return res.keys;
    },
    retry: false,
  });

  const loginM = useMutation({
    mutationFn: async () => {
      const res = await postFunction<ApiOk<{ token: string }>>(
        "/rent-user",
        { action: "login", username: username.trim(), password },
        {},
      );
      return res.token;
    },
    onSuccess: (t) => {
      if (typeof window !== "undefined") window.localStorage.setItem(LS_TOKEN, t);
      setToken(t);
      setPassword("");
      toast({ title: "Đăng nhập thành công" });
    },
    onError: (e: any) => {
      toast({ title: "Đăng nhập thất bại", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const activateM = useMutation({
    mutationFn: async () => {
      const res = await postFunction<ApiOk<{ expires_at: string }>>(
        "/rent-user",
        { action: "activate", code: activationKey.trim().toUpperCase() },
        { authToken: token ?? undefined },
      );
      return res;
    },
    onSuccess: (res) => {
      toast({ title: "Kích hoạt thành công", description: `Hết hạn: ${new Date(res.expires_at).toLocaleString()}` });
      setActivationKey("");
      qc.invalidateQueries({ queryKey: ["rent", "me"] });
      qc.invalidateQueries({ queryKey: ["rent", "keys"] });
    },
    onError: (e: any) => {
      toast({ title: "Kích hoạt thất bại", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const createKeyM = useMutation({
    mutationFn: async (mode: "random" | "custom") => {
      const res = await postFunction<ApiOk<{ key: RentKey }>>(
        "/rent-user",
        {
          action: mode === "random" ? "generate_key" : "create_key",
          key: mode === "custom" ? normalizeKeyInput(customKey) : null,
          note: keyNote.trim() || null,
        },
        { authToken: token ?? undefined },
      );
      return res.key;
    },
    onSuccess: (k) => {
      toast({ title: "Đã tạo key", description: k.key });
      setCustomKey("");
      setKeyNote("");
      qc.invalidateQueries({ queryKey: ["rent", "keys"] });
    },
    onError: (e: any) => {
      toast({ title: "Lỗi tạo key", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const toggleKeyM = useMutation({
    mutationFn: async (k: RentKey) => {
      const res = await postFunction<ApiOk<{ key: RentKey }>>(
        "/rent-user",
        { action: "toggle_key", key_id: k.id, is_active: !k.is_active },
        { authToken: token ?? undefined },
      );
      return res.key;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["rent", "keys"] });
    },
    onError: (e: any) => {
      toast({ title: "Lỗi cập nhật key", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const deleteKeyM = useMutation({
    mutationFn: async (key_id: string) => {
      const res = await postFunction<ApiOk<{}>>(
        "/rent-user",
        { action: "delete_key", key_id },
        { authToken: token ?? undefined },
      );
      return res;
    },
    onSuccess: () => {
      toast({ title: "Đã xóa key" });
      qc.invalidateQueries({ queryKey: ["rent", "keys"] });
    },
    onError: (e: any) => {
      toast({ title: "Lỗi xóa key", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const resetPassM = useMutation({
    mutationFn: async () => {
      const res = await postFunction<ApiOk<{}>>(
        "/rent-user",
        { action: "reset_password", username: username.trim(), code: resetCode.trim(), new_password: newPass },
        {},
      );
      return res;
    },
    onSuccess: () => {
      toast({ title: "Đổi mật khẩu thành công" });
      setResetCode("");
      setNewPass("");
    },
    onError: (e: any) => {
      toast({ title: "Đổi mật khẩu thất bại", description: String(e?.message ?? e), variant: "destructive" });
    },
  });

  const account = meQ.data;
  const isActive = !!account?.expires_at && new Date(account.expires_at).getTime() > Date.now() && !account.is_disabled;

  return (
    <div className="mx-auto w-full max-w-4xl space-y-6 p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Thuê Website</h1>
          <p className="text-sm text-muted-foreground">
            Đây là portal cho người thuê. Bạn cần key kích hoạt do admin cấp để dùng các chức năng.
          </p>
        </div>
        {token && (
          <Button variant="soft" onClick={logout}>
            Đăng xuất
          </Button>
        )}
      </div>

      {!token ? (
        <Card>
          <CardHeader>
            <CardTitle>Đăng nhập</CardTitle>
            <CardDescription>Đăng nhập tài khoản thuê (khác tài khoản admin).</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Username</Label>
              <Input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="user123" />
              <p className="text-xs text-muted-foreground">Không dùng email để tránh nhầm với login admin.</p>
            </div>
            <div className="space-y-2">
              <Label>Password</Label>
              <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
              <p className="text-xs text-muted-foreground">Mật khẩu do admin cấp hoặc bạn tự đổi bằng code.</p>
            </div>
            <div className="md:col-span-2">
              <Button onClick={() => loginM.mutate()} disabled={!username.trim() || !password || loginM.isPending}>
                {loginM.isPending ? "Đang đăng nhập..." : "Đăng nhập"}
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <>
          <Card>
            <CardHeader>
              <CardTitle>Trạng thái</CardTitle>
              <CardDescription>Kiểm tra thuê còn hạn hay chưa. Nếu chưa kích hoạt, hãy nhập key kích hoạt.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {meQ.isLoading ? (
                <div className="text-sm text-muted-foreground">Đang tải...</div>
              ) : meQ.isError ? (
                <div className="text-sm text-destructive">Không lấy được trạng thái. Thử đăng xuất rồi đăng nhập lại.</div>
              ) : account ? (
                <div className="space-y-2">
                  <div className="text-sm">
                    <span className="font-medium">User:</span> {account.username}
                  </div>
                  <div className="text-sm">
                    <span className="font-medium">Hết hạn:</span>{" "}
                    {account.expires_at ? new Date(account.expires_at).toLocaleString() : "Chưa kích hoạt"}
                  </div>
                  <div className="text-sm">
                    <span className="font-medium">Max devices:</span> {account.max_devices}
                  </div>
                  {account.is_disabled && (
                    <div className="text-sm text-destructive">Tài khoản đã bị khóa. Liên hệ admin.</div>
                  )}
                </div>
              ) : null}

              {!isActive && (
                <>
                  <Separator />
                  <div className="space-y-2">
                    <Label>Nhập key kích hoạt</Label>
                    <Input value={activationKey} onChange={(e) => setActivationKey(e.target.value)} placeholder="RENT-XXXX-XXXX..." />
                    <p className="text-xs text-muted-foreground">
                      Chưa kích hoạt thì không dùng được chức năng (server chặn, không bypass bằng F12/F5).
                    </p>
                    <Button onClick={() => activateM.mutate()} disabled={!activationKey.trim() || activateM.isPending}>
                      {activateM.isPending ? "Đang kích hoạt..." : "Kích hoạt"}
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Tạo key</CardTitle>
              <CardDescription>Key của user thuê có dạng XXXX-XXXX-XXXX-XXXX (không có SUNNY-).</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!isActive ? (
                <div className="text-sm text-muted-foreground">Bạn cần kích hoạt trước khi tạo key.</div>
              ) : (
                <>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Custom key (tuỳ chọn)</Label>
                      <Input value={customKey} onChange={(e) => setCustomKey(e.target.value)} placeholder="ABCD-EFGH-IJKL-MNOP" />
                      <p className="text-xs text-muted-foreground">Chỉ A-Z/0-9, 4 nhóm x 4 ký tự.</p>
                    </div>
                    <div className="space-y-2">
                      <Label>Note (tuỳ chọn)</Label>
                      <Input value={keyNote} onChange={(e) => setKeyNote(e.target.value)} placeholder="Ghi chú..." />
                      <p className="text-xs text-muted-foreground">Gắn note để dễ quản lý.</p>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <Button onClick={() => createKeyM.mutate("random")} disabled={createKeyM.isPending}>
                      Random key
                    </Button>
                    <Button
                      variant="soft"
                      onClick={() => createKeyM.mutate("custom")}
                      disabled={createKeyM.isPending || !customKey.trim()}
                    >
                      Tạo key theo ý
                    </Button>
                  </div>

                  <Separator />

                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Key</TableHead>
                          <TableHead>Created</TableHead>
                          <TableHead>Active</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(keysQ.data ?? []).map((k) => (
                          <TableRow key={k.id}>
                            <TableCell className="font-mono">{k.key}</TableCell>
                            <TableCell>{new Date(k.created_at).toLocaleString()}</TableCell>
                            <TableCell>{k.is_active ? "ON" : "OFF"}</TableCell>
                            <TableCell className="text-right space-x-2">
                              <Button size="sm" variant="soft" onClick={() => toggleKeyM.mutate(k)} disabled={toggleKeyM.isPending}>
                                {k.is_active ? "Tắt" : "Bật"}
                              </Button>
                              <Button size="sm" variant="destructive" onClick={() => deleteKeyM.mutate(k.id)} disabled={deleteKeyM.isPending}>
                                Xóa
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                        {(keysQ.data ?? []).length === 0 && (
                          <TableRow>
                            <TableCell colSpan={4} className="text-center text-sm text-muted-foreground">
                              Chưa có key.
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Đổi mật khẩu bằng code (1 lần)</CardTitle>
              <CardDescription>Admin tạo code 1 lần. Bạn nhập code để đổi mật khẩu mới.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Username</Label>
                <Input value={username} onChange={(e) => setUsername(e.target.value)} placeholder="user123" />
                <p className="text-xs text-muted-foreground">Nhập đúng username tài khoản thuê.</p>
              </div>
              <div className="space-y-2">
                <Label>Code</Label>
                <Input value={resetCode} onChange={(e) => setResetCode(e.target.value)} placeholder="RC-..." />
                <p className="text-xs text-muted-foreground">Code dùng 1 lần và có hạn.</p>
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>New password</Label>
                <Input type="password" value={newPass} onChange={(e) => setNewPass(e.target.value)} placeholder="••••••••" />
                <p className="text-xs text-muted-foreground">Sau khi đổi, đăng nhập lại bằng mật khẩu mới.</p>
              </div>
              <div className="md:col-span-2">
                <Button onClick={() => resetPassM.mutate()} disabled={!username.trim() || !resetCode.trim() || !newPass || resetPassM.isPending}>
                  {resetPassM.isPending ? "Đang đổi..." : "Đổi mật khẩu"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
