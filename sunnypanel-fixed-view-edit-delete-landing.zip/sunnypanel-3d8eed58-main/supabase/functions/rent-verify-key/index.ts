import { createClient } from "npm:@supabase/supabase-js@2";
import { z } from "npm:zod@3";
import { buildCorsHeaders, handleOptions } from "../_shared/cors.ts";
import { hmacSha256Hex, isValidRentKeyFormat } from "../_shared/rent.ts";

function inferBaseUrl(req: Request) {
  const origin = req.headers.get("origin");
  if (origin) return origin;
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  const proto = req.headers.get("x-forwarded-proto") ?? "https";
  if (host) return `${proto}://${host}`;
  return "https://mityangho.id.vn";
}

function json(req: Request, publicBaseUrl: string, data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      ...buildCorsHeaders(req, publicBaseUrl, "POST,OPTIONS"),
      "Content-Type": "application/json",
    },
  });
}

Deno.serve(async (req) => {
  const publicBaseUrl = Deno.env.get("PUBLIC_BASE_URL") ?? inferBaseUrl(req);
  if (req.method === "OPTIONS") return handleOptions(req, publicBaseUrl, "POST,OPTIONS");

  const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
  const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

  if (!supabaseUrl || !serviceRole) {
    return json(req, publicBaseUrl, { ok: false, code: "SERVER_MISCONFIG_MISSING_SECRET", msg: "Missing backend secrets" }, 503);
  }

  const sb = createClient(supabaseUrl, serviceRole, { auth: { persistSession: false } });

  let body: any = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  try {
    const Schema = z.object({
      username: z.string().min(3).max(64),
      key: z.string().min(8).max(64),
      device_id: z.string().min(3).max(256),
      ts: z.union([z.number().int(), z.string()]),
      sig: z.string().min(16).max(128),
    });

    const parsed = Schema.parse(body);
    const username = parsed.username.trim().toLowerCase();
    const key = parsed.key.trim().toUpperCase();
    const device_id = parsed.device_id.trim();
    const ts = typeof parsed.ts === "string" ? parseInt(parsed.ts, 10) : parsed.ts;
    const sig = parsed.sig.trim().toLowerCase();

    if (!isValidRentKeyFormat(key)) {
      return json(req, publicBaseUrl, { ok: true, valid: false, code: "INVALID_KEY_FORMAT" }, 200);
    }
    const nowSec = Math.floor(Date.now() / 1000);
    if (!Number.isFinite(ts) || Math.abs(nowSec - ts) > 5 * 60) {
      return json(req, publicBaseUrl, { ok: true, valid: false, code: "BAD_TIMESTAMP" }, 200);
    }

    const { data: acc, error: accErr } = await sb.schema("rent").from("accounts")
      .select("id,username,expires_at,max_devices,is_disabled,hmac_secret")
      .eq("username", username)
      .single();

    if (accErr || !acc) return json(req, publicBaseUrl, { ok: true, valid: false, code: "NO_ACCOUNT" }, 200);
    if (acc.is_disabled) return json(req, publicBaseUrl, { ok: true, valid: false, code: "ACCOUNT_DISABLED" }, 200);
    if (!acc.expires_at || new Date(acc.expires_at).getTime() <= Date.now()) return json(req, publicBaseUrl, { ok: true, valid: false, code: "SUBSCRIPTION_EXPIRED" }, 200);

    const { data: rk, error: keyErr } = await sb.schema("rent").from("keys")
      .select("id,account_id,is_active")
      .eq("key", key)
      .maybeSingle();

    if (keyErr || !rk || rk.account_id !== acc.id) return json(req, publicBaseUrl, { ok: true, valid: false, code: "KEY_NOT_FOUND" }, 200);
    if (!rk.is_active) return json(req, publicBaseUrl, { ok: true, valid: false, code: "KEY_DISABLED" }, 200);

    const msg = `${username}|${key}|${device_id}|${ts}`;
    const expected = (await hmacSha256Hex(acc.hmac_secret, msg)).toLowerCase();
    if (expected !== sig) return json(req, publicBaseUrl, { ok: true, valid: false, code: "BAD_SIGNATURE" }, 200);

    // Device binding
    const { data: existing } = await sb.schema("rent").from("key_devices")
      .select("id")
      .eq("key_id", rk.id)
      .eq("device_id", device_id)
      .maybeSingle();

    if (!existing) {
      const { count } = await sb.schema("rent").from("key_devices")
        .select("*", { count: "exact", head: true })
        .eq("key_id", rk.id);

      const currentCount = count ?? 0;
      if (currentCount >= (acc.max_devices ?? 1)) {
        return json(req, publicBaseUrl, { ok: true, valid: false, code: "DEVICE_LIMIT" }, 200);
      }

      const { error: insErr } = await sb.schema("rent").from("key_devices").insert({
        key_id: rk.id,
        device_id,
      });
      if (insErr) throw new Error(insErr.message);
    } else {
      await sb.schema("rent").from("key_devices").update({ last_seen: new Date().toISOString() }).eq("id", existing.id);
    }

    return json(req, publicBaseUrl, {
      ok: true,
      valid: true,
      expires_at: acc.expires_at,
      max_devices: acc.max_devices,
    }, 200);
  } catch (e: any) {
    return json(req, publicBaseUrl, { ok: false, code: "ERROR", msg: String(e?.message ?? e) }, 400);
  }
});
