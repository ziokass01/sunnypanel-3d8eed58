import { createClient } from "npm:@supabase/supabase-js@2";
import { z } from "npm:zod@3";
import { assertAdmin } from "../_shared/admin.ts";
import { resolveCorsOrigin } from "../_shared/cors.ts";

function inferBaseUrl(req: Request) {
  const origin = req.headers.get("origin");
  if (origin) return origin;
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
  const proto = req.headers.get("x-forwarded-proto") ?? "https";
  if (host) return `${proto}://${host}`;
  return "";
}

function toHex(bytes: ArrayBuffer) {
  return Array.from(new Uint8Array(bytes))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

async function sha256Hex(input: string) {
  const data = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return toHex(digest);
}

function getClientIp(req: Request) {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim();
  return req.headers.get("cf-connecting-ip") ?? req.headers.get("x-real-ip") ?? "";
}

function base64url(bytesLen = 32) {
  const bytes = new Uint8Array(bytesLen);
  crypto.getRandomValues(bytes);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

const BodySchema = z.object({
  key_type_code: z.string().min(2).max(8),
  fingerprint: z.string().min(6).max(128).optional(),
  test_mode: z.boolean().optional().default(false),
});

function isMissingRateLimitSetup(error: { message?: string | null; details?: string | null; hint?: string | null } | null | undefined) {
  const haystack = `${error?.message ?? ""} ${error?.details ?? ""} ${error?.hint ?? ""}`.toLowerCase();
  return haystack.includes("check_free_ip_rate_limit")
    || haystack.includes("check_free_fp_rate_limit")
    || haystack.includes("could not find the function")
    || haystack.includes("does not exist")
    || (haystack.includes("relation") && haystack.includes("rate_limit"));
}

function isActiveBlockUntil(blockedUntil?: string | null) {
  if (!blockedUntil) return true;
  const t = Date.parse(blockedUntil);
  return Number.isFinite(t) && t > Date.now();
}

async function safeInsertStartErrorSession(
  sb: any,
  payload: {
    ipHash: string;
    uaHash: string;
    fpHash: string;
    keyTypeCode: string;
    lastError: string;
  },
) {
  try {
const now = new Date();
    await sb.from("licenses_free_sessions").insert({
      status: "start_error",
      reveal_count: 0,
      ip_hash: payload.ipHash,
      ua_hash: payload.uaHash,
      fingerprint_hash: payload.fpHash,
      key_type_code: payload.keyTypeCode,
      duration_seconds: 0,
      started_at: now.toISOString(),
      expires_at: new Date(now.getTime() + 3 * 60 * 1000).toISOString(),
      last_error: payload.lastError,
    });
  } catch {
    // no-op
  }
}

Deno.serve(async (req) => {
  const PUBLIC_BASE_URL = Deno.env.get("PUBLIC_BASE_URL") ?? "";
  const origin = req.headers.get("origin") ?? "";
  const allowOrigin = resolveCorsOrigin(origin, PUBLIC_BASE_URL);
  const corsHeaders = {
    "Access-Control-Allow-Origin": allowOrigin,
    "Vary": "Origin",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-fp",
    "Access-Control-Max-Age": "86400",
  };
  const jsonResponse = (data: unknown, status = 200) =>
    new Response(JSON.stringify(data), {
      status,
      headers: {
        ...corsHeaders,
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
      },
    });

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders, status: 204 });
  }
  if (req.method !== "POST") {
    return jsonResponse({ ok: false, msg: "METHOD_NOT_ALLOWED" }, 405);
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceRole = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    if (!supabaseUrl || !serviceRole) {
      return jsonResponse({
        ok: false,
        msg: "SERVER_MISCONFIG_MISSING_SECRET",
        detail: !supabaseUrl ? "SUPABASE_URL missing" : "SUPABASE_SERVICE_ROLE_KEY missing",
      }, 500);
    }

    const sb: any = createClient<any>(supabaseUrl, serviceRole, { auth: { persistSession: false } });
    const safeLogSecurity = async (event_type: string, details: Record<string, unknown>, ip_hash?: string, fingerprint_hash?: string | null) => {
      try {
        await sb.from("licenses_free_security_logs").insert({
          event_type,
          route: "free-start",
          details,
          ip_hash: ip_hash ?? null,
          fingerprint_hash: fingerprint_hash ?? null,
        });
      } catch {
        // no-op
      }
    };

    let body: unknown = null;
    try {
      body = await req.json();
    } catch {
      body = {};
    }

    const parsed = BodySchema.safeParse(body);
    if (!parsed.success) {
      return jsonResponse({ ok: false, msg: "BAD_REQUEST" }, 400);
    }

    const { key_type_code, test_mode } = parsed.data;
    const fpFromHeader = (req.headers.get("x-fp") ?? "").trim();
    const fingerprint = fpFromHeader || parsed.data.fingerprint || "";

    if (test_mode) {
      const admin = await assertAdmin(req);
      if (!admin.ok) return jsonResponse({ ok: false, msg: "UNAUTHORIZED" }, admin.status);
    }

    // Settings
    const { data: settings, error: sErr } = await sb
      .from("licenses_free_settings")
      .select("free_outbound_url,free_outbound_url_pass2,free_enabled,free_disabled_message,free_min_delay_enabled,free_min_delay_seconds,free_min_delay_seconds_pass2,free_link4m_rotate_days")
      .eq("id", 1)
      .maybeSingle();

    if (sErr) {
      return jsonResponse({ ok: false, msg: sErr.message }, 500);
    }

    const free_enabled = Boolean(settings?.free_enabled ?? true);
    if (!free_enabled) {
      return jsonResponse({ ok: false, msg: "CLOSED" }, 403);
    }

    const rawOutbound = String(settings?.free_outbound_url ?? "").trim();
    const fallbackOutbound = "https://link4m.com/PkY7X";

    const baseUrl = inferBaseUrl(req) || PUBLIC_BASE_URL;
    if (!baseUrl) {
      return jsonResponse({ ok: false, code: "SERVER_MISCONFIG", msg: "Missing PUBLIC_BASE_URL" }, 500);
    }

    const claim_base_url = `${baseUrl}/free/claim`;

const LINK4M_API_TOKEN_PASS1 = (Deno.env.get("LINK4M_API_TOKEN_PASS1") ?? "").trim();
const LINK4M_API_TOKEN_PASS2 = (Deno.env.get("LINK4M_API_TOKEN_PASS2") ?? "").trim();

function computeRotateBucket(rotateDays: number) {
  const days = Math.max(1, Math.floor(Number(rotateDays) || 7));
  const epochDays = Math.floor(Date.now() / 86400000); // UTC-ish
  const bucket = Math.floor(epochDays / days);
  return String(bucket);
}

function applyTemplateApiToken(tpl: string, token: string) {
  const v = String(tpl || "");
  if (!token) return v;
  if (v.includes("{LINK4M_API_TOKEN}")) return v.replaceAll("{LINK4M_API_TOKEN}", token);
  return v;
}

const rotateDays = Number((settings as any)?.free_link4m_rotate_days ?? 7);
const rotate_bucket = computeRotateBucket(rotateDays);


    // Create a token-based session (expires quickly)
    const out_token = base64url(32);
    const out_token_hash = await sha256Hex(out_token);

    function buildOutboundUrl(outboundBase: string, gateUrl: string) {
      const tpl = String(outboundBase || "").trim();
      const g = String(gateUrl || "").trim();
      if (!tpl) return "";

      const hasPlaceholder = tpl.includes("{GATE_URL_ENC}") || tpl.includes("{GATE_URL}");

      // IMPORTANT: do NOT guess param names for Link4M.
      // If admin provides a Link4M URL but forgets placeholder, return explicit error.
      try {
        const u = new URL(tpl);
        const host = (u.hostname || "").toLowerCase();
        if (host.includes("link4m") && !hasPlaceholder) {
          // Allow Link4M "quick link" formats (no placeholder required):
          // - https://link4m.co/st?api=TOKEN&url=...
          // - https://link4m.co/api-shorten/v2?api=TOKEN&url=...
          // In these cases we overwrite the `url` param with the current gateUrl.
          const path = (u.pathname || "").replace(/\/+$/, "");
          const hasApi = u.searchParams.has("api") || u.searchParams.has("apikey") || u.searchParams.has("token");
          const looksQuick = (path.endsWith("/st") || path.includes("api-shorten")) && hasApi;
          const hasUrl = u.searchParams.has("url");
          if (looksQuick || hasUrl) {
            u.searchParams.set("url", g);
            return u.toString();
          }
          return "__TEMPLATE_INVALID__";
        }
      } catch {
        // ignore
      }

      if (tpl.includes("{GATE_URL_ENC}")) return tpl.replaceAll("{GATE_URL_ENC}", encodeURIComponent(g));
      if (tpl.includes("{GATE_URL}")) return tpl.replaceAll("{GATE_URL}", g);

      // For non-Link4M URLs, we keep a safe default of appending url=<gate>.
      try {
        const u = new URL(tpl);
        u.searchParams.append("url", g);
        return u.toString();
      } catch {
        // Fallback: naive append
        return tpl + (tpl.includes("?") ? "&" : "?") + `url=${encodeURIComponent(g)}`;
      }
    }

    const outboundBase = rawOutbound || fallbackOutbound;

    // Key type must be enabled (keep this before session insert)
    // We'll build gate_url AFTER we have session_id.
    const { data: kt, error: kErr } = await sb
      .from("licenses_free_key_types")
      .select("code,label,duration_seconds,enabled,requires_double_gate")
      .eq("code", key_type_code)
      .maybeSingle();

    if (kErr) {
      return jsonResponse({ ok: false, msg: kErr.message }, 500);
    }
    if (!kt || !kt.enabled) {
      return jsonResponse({ ok: false, msg: "KEY_TYPE_DISABLED" }, 400);
    }

    const ua = req.headers.get("user-agent") ?? "";
    const ip = getClientIp(req);

    const fpHash = fingerprint ? await sha256Hex(fingerprint) : await sha256Hex(`missing:${ua}:${ip}`);
    const uaHash = await sha256Hex(ua);
    const ipHash = await sha256Hex(ip);

    const rl = await (async () => {
      // Support both newer signature (p_route, p_window_seconds) and legacy (p_window_sec, no p_route)
      const primary = await sb.rpc("check_free_ip_rate_limit", {
        p_ip_hash: ipHash,
        p_route: "free-start",
        p_limit: 25,
        p_window_seconds: 60,
      });
      if (!primary.error) return primary;

      const legacy = await sb.rpc("check_free_ip_rate_limit", {
        p_ip_hash: ipHash,
        p_limit: 25,
        p_window_sec: 60,
      });
      return legacy;
    })();
    if (rl.error) {
      if (isMissingRateLimitSetup(rl.error)) {
        await safeInsertStartErrorSession(sb, {
          ipHash,
          uaHash,
          fpHash,
          keyTypeCode: key_type_code,
          lastError: "SERVER_RATE_LIMIT_MISCONFIG",
        });
         return jsonResponse(
           {
             ok: false,
             code: "SERVER_RATE_LIMIT_MISCONFIG",
             msg: "Server thiếu migration FREE (thiếu RPC/bảng rate-limit). Cần chạy: 20260205101000_free_schema.sql, 20260205170000_free_rate_limit_and_admin_controls.sql, 20260206150000_free_schema_runtime_fix.sql",
           },
           503,
         );
      }
      await safeLogSecurity("rate_limit_error", { key_type_code, error: rl.error.message || "unknown" }, ipHash, fpHash);
      await safeInsertStartErrorSession(sb, {
        ipHash,
        uaHash,
        fpHash,
        keyTypeCode: key_type_code,
        lastError: "RATE_LIMIT_CHECK_FAILED",
      });
      return jsonResponse({ ok: false, msg: "RATE_LIMIT_CHECK_FAILED", detail: "Kiểm tra RPC check_free_ip_rate_limit/check_free_fp_rate_limit và bảng licenses_free_*" }, 500);
    }
    const allowed = Array.isArray(rl.data) ? rl.data[0]?.allowed : rl.data?.allowed;
    if (allowed === false) {
      await safeLogSecurity("rate_limit_ip_blocked", { key_type_code }, ipHash, fingerprint ? fpHash : null);
      return jsonResponse({ ok: false, msg: "RATE_LIMIT" }, 429);
    }

    if (fingerprint) {
       const fpRl = await (async () => {
         const primary = await sb.rpc("check_free_fp_rate_limit", {
           p_fp_hash: fpHash,
           p_route: "free-start",
           p_limit: 12,
           p_window_seconds: 60,
         });
         if (!primary.error) return primary;

         const legacy = await sb.rpc("check_free_fp_rate_limit", {
           p_fp_hash: fpHash,
           p_route: "free-start",
           p_limit: 12,
           p_window_sec: 60,
         });
         return legacy;
       })();
      if (fpRl.error) {
        if (isMissingRateLimitSetup(fpRl.error)) {
          await safeInsertStartErrorSession(sb, {
            ipHash,
            uaHash,
            fpHash,
            keyTypeCode: key_type_code,
            lastError: "SERVER_RATE_LIMIT_MISCONFIG",
          });
           return jsonResponse(
             {
               ok: false,
               code: "SERVER_RATE_LIMIT_MISCONFIG",
               msg: "Server thiếu migration FREE (thiếu RPC/bảng rate-limit). Cần chạy: 20260205101000_free_schema.sql, 20260205170000_free_rate_limit_and_admin_controls.sql, 20260206150000_free_schema_runtime_fix.sql",
             },
             503,
           );
        }
        await safeInsertStartErrorSession(sb, {
          ipHash,
          uaHash,
          fpHash,
          keyTypeCode: key_type_code,
          lastError: "RATE_LIMIT_CHECK_FAILED",
        });
        return jsonResponse({ ok: false, msg: "RATE_LIMIT_CHECK_FAILED", detail: "Kiểm tra RPC check_free_ip_rate_limit/check_free_fp_rate_limit và bảng licenses_free_*" }, 500);
      }
      const fpAllowed = Array.isArray(fpRl.data) ? fpRl.data[0]?.allowed : fpRl.data?.allowed;
      if (fpAllowed === false) {
        await safeLogSecurity("rate_limit_fp_blocked", { key_type_code }, ipHash, fpHash);
        return jsonResponse({ ok: false, msg: "RATE_LIMIT" }, 429);
      }
    }

    const banned = await sb
      .from("licenses_free_blocklist")
      .select("id,blocked_until")
      .eq("enabled", true)
      .or(`fingerprint_hash.eq.${fpHash},ip_hash.eq.${ipHash}`)
      .limit(1)
      .maybeSingle();
    if (banned.data?.id && isActiveBlockUntil((banned.data as any).blocked_until)) {
      await safeLogSecurity("blocklist_hit", { key_type_code }, ipHash, fingerprint ? fpHash : null);
      return jsonResponse({ ok: false, msg: "BLOCKED" }, 403);
    }

    // out_token generated above (must be included in gate_url + stored hashed in session)
    // const out_token = base64url(32);
    // const out_token_hash = await sha256Hex(out_token);

    const now = new Date();
    const started_at = now.toISOString();
    const expires_at = new Date(now.getTime() + 30 * 60 * 1000).toISOString(); // 30 minutes
    const out_expires_at = expires_at;

    const duration_seconds = Number(kt.duration_seconds ?? 0);

    const { data: insData, error: insErr } = await sb.from("licenses_free_sessions").insert({
      status: "started",
      reveal_count: 0,
      ip_hash: ipHash,
      ua_hash: uaHash,
      fingerprint_hash: fpHash,
      started_at,
      expires_at,
      out_token_hash,
      out_expires_at,
      key_type_code,
      duration_seconds,
      passes_required: Boolean((kt as any).requires_double_gate) ? 2 : 1,
      passes_completed: 0,
      current_pass: 1,
      rotate_bucket,
    }).select("session_id").single();

    if (insErr || !insData?.session_id) {
      return jsonResponse({ ok: false, code: "SERVER_ERROR", msg: insErr?.message ?? "SESSION_INSERT_FAILED" }, 500);
    }

    const session_id = insData.session_id as string;
    

const gate_url_pass1 = `${baseUrl}/free/gate?p=1&b=${encodeURIComponent(rotate_bucket)}`;
const gate_url_pass2 = `${baseUrl}/free/gate?p=2&b=${encodeURIComponent(rotate_bucket)}`;

// Outbound templates
const outboundBasePass1 = rawOutbound || fallbackOutbound;
const rawOutboundPass2 = String((settings as any)?.free_outbound_url_pass2 ?? "").trim();
const outboundBasePass2 = rawOutboundPass2 || outboundBasePass1;

const token1 = LINK4M_API_TOKEN_PASS1;
const token2 = LINK4M_API_TOKEN_PASS2 || LINK4M_API_TOKEN_PASS1;

const tpl1 = applyTemplateApiToken(outboundBasePass1, token1);
const tpl2 = applyTemplateApiToken(outboundBasePass2, token2);

const builtOutbound = test_mode ? gate_url_pass1 : buildOutboundUrl(tpl1, gate_url_pass1);
const builtOutboundPass2 = test_mode ? gate_url_pass2 : buildOutboundUrl(tpl2, gate_url_pass2);
    if (!builtOutbound) return jsonResponse({ ok: false, code: "MISSING_OUTBOUND_URL", msg: "MISSING_OUTBOUND_URL" }, 500);
    if (builtOutbound === "__TEMPLATE_INVALID__") {
      return jsonResponse(
        {
          ok: false,
          code: "OUTBOUND_URL_TEMPLATE_INVALID",
          msg:
            "Link4M outbound template thiếu placeholder. Hãy dùng {GATE_URL_ENC} hoặc {GATE_URL}. Ví dụ: https://link4m.com/PkY7X?redirect={GATE_URL_ENC}",
        },
        400,
      );
    }

    const outbound_url = builtOutbound;

    const minDelayEnabled = Boolean((settings as any)?.free_min_delay_enabled ?? true);
    const minDelayRaw = Number(minDelayEnabled ? ((settings as any)?.free_min_delay_seconds ?? 25) : 0);
    const min_delay_seconds = Math.max(0, minDelayRaw); // allow 0 to disable

    const minDelayPass2Raw = Number((settings as any)?.free_min_delay_seconds_pass2 ?? min_delay_seconds);
    const min_delay_seconds_pass2 = Math.max(0, minDelayEnabled ? (Math.floor(minDelayPass2Raw) || min_delay_seconds) : 0);

    return jsonResponse({ ok: true, out_token, session_id, outbound_url, outbound_url_pass2: builtOutboundPass2, gate_url: gate_url_pass1, gate_url_pass2, claim_base_url, min_delay_seconds, min_delay_seconds_pass2, passes_required: Boolean((kt as any).requires_double_gate) ? 2 : 1, rotate_bucket }, 200);
  } catch (error) {
    console.error("free-start error", error);
    return jsonResponse({
      ok: false,
      msg: "SERVER_ERROR",
      detail: error instanceof Error ? error.message : String(error),
    }, 500);
  }
});
